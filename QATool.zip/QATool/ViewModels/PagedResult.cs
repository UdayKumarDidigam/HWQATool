﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QATool.ViewModels
{
    public class PagedResult<T>
    {
        public PagingInfo Pager { get; private set; }
        public List<T> Items { get; set; }
        public class PagingInfo
        {
            public int PageIndex { get; set; }

            public int PageSize { get; set; }

            public int TotalPageCount { get; set; }

            public long TotalRecordCount { get; set; }
        }
        
        public PagedResult(IEnumerable<T> items, int pageNo, int pageSize)
        {
            // Determine the number of records to skip
            int skip = (pageNo - 1) * pageSize;

            // Get total number of records
            int total = items.Count();

            // Select the list based on paging parameters
            var pagedItems = items
                .Skip(skip)
                .Take(pageSize)
                .ToList();

            Items = pagedItems.ToList<T>();
            Pager = new PagingInfo
            {
                PageIndex = pageNo,
                PageSize = pageSize,
                TotalRecordCount = total,
                TotalPageCount = total > 0
                    ? (int)Math.Ceiling(total / (double)pageSize)
                    : 0
            };
        }
    }
}