﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('TeamController', TeamController);

    TeamController.$inject = ['TeamService', '$rootScope', 'PagerService', '$aside', '$scope', 'FlashService', '$http'];
    function TeamController(TeamService, $rootScope, PagerService, $aside, $scope, FlashService, $http) {
        var vm = this;

        vm.team = null;
        vm.allTeams = [];
        vm.addTeam = addTeam;
        vm.updateTeam = updateTeam;
        vm.deleteTeam = deleteTeam;
        vm.openAside = openAside;

        (function initController() {
            initPage();
            loadAllTeams();
            //loadCurrentTeam();           
            initAsideModal();
        })();

        function loadAllTeams() {
            TeamService.GetAll()
                .then(function (teams) {
                    vm.teams = teams;
                    vm.setPage(1);
                });
        }



        function addTeam() {
            vm.dataLoading = true;
            TeamService.Create(vm.team)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Registration successful', true);
                        vm.myAside.hide();
                        loadAllTeams();
                        vm.dataLoading = false;
                    } else {
                        FlashService.Error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }

        function updateTeam() {
            vm.dataLoading = true;
            TeamService.Update(vm.team)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Updated successful', true);
                        vm.myAside.hide();
                        loadAllTeams();
                        vm.dataLoading = false;
                    } else {
                        FlashService.Error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }

        function deleteTeam(id) {
            TeamService.Delete(id)
            .then(function () {
                loadAllTeams();
            });
        }

        function openAside(teamId) {
            (teamId != 0) ? loadTeam(teamId, function () {
                vm.myAside.$promise.then(function () {
                    vm.myAside.show();
                });
            }) : vm.myAside.$promise.then(function () {
                vm.team = {};
                vm.myAside.show();
            });;
        }

        

        function initPage() {
            vm.pager = {};
            vm.setPage = setPage;
        }

        function setPage(page) {
            if (page < 1 || page > vm.pager.totalPages) {
                return;
            }

            // get pager object from service
            vm.pager = PagerService.GetPager(vm.allTeams.length, page);

            // get current page of items
            vm.pagedTeams = vm.allTeams.slice(vm.pager.startIndex, vm.pager.endIndex);
        }

        function initAsideModal() {
            vm.myAside = $aside({
                scope: $scope,
                title: 'Add Team',
                //content: vm.teamId,
                templateUrl: 'views/team/add-edit-team.html',
                container: "body",
                show: false,
                backdrop: "static",
                animation: "am-slide-top",
                keyboard: "false",
                placement: "left"
            });
        }

        function loadCurrentTeam() {
            TeamService.GetByTeamname($rootScope.globals.currentTeam.teamname)
                .then(function (team) {
                    vm.currentteam = team;
                });
        }

        function loadTeam(teamId, callback) {
            TeamService.GetById(teamId)
                .then(function (team) {
                    vm.team = team;
                    callback();
                });
        }

        
    }
})();