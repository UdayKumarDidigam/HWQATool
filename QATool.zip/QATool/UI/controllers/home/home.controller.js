﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['UserService', '$rootScope', 'PagerService', '$aside', '$scope', 'FlashService', '$http'];
    function HomeController(UserService, $rootScope, PagerService, $aside, $scope, FlashService, $http) {
        var vm = this;

        vm.user = null;
        vm.allUsers = [];
        vm.addUser = addUser;
        vm.updateUser = updateUser;
        vm.deleteUser = deleteUser;
        vm.openAside = openAside;

        function addUser() {
            vm.dataLoading = true;
            UserService.Create(vm.user)
                .then(function (response) {
                    debugger;
                    if (response.success) {
                        FlashService.Success('Registration successful', true);
                        vm.myAside.hide();
                        loadAllUsers();
                        vm.dataLoading = false;
                    } else {
                        FlashService.Error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }

        function updateUser() {
            vm.dataLoading = true;
            UserService.Update(vm.user)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Updated successful', true);
                        vm.myAside.hide();
                        loadAllUsers();
                        vm.dataLoading = false;
                    } else {
                        FlashService.Error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }

        function deleteUser(id) {
            UserService.Delete(id)
            .then(function () {
                loadAllUsers();
            });
        }

        function openAside(userId) {
            (userId != 0) ? loadUser(userId, function () {
                vm.myAside.$promise.then(function () {
                    vm.myAside.show();
                });
            }) : vm.myAside.$promise.then(function () {
                vm.user = {};
                vm.myAside.show();
            });;
        }

        (function initController() {
            //var config = {
            //    headers: {
            //        'Authorization': 'Basic d2VudHdvcnRobWFuOkNoYW5nZV9tZQ==',
            //        'Accept': 'application/json;odata=verbose',
            //        "X-Testing": "testing",
            //        "Access-Control-Allow-Origin": "*"
            //    }
            //};

            $http.get('http://localhost:53612/api/Values').then(function (response) {
                debugger;
            }, function (error) {
                debugger;
            })

            loadCurrentUser();
            loadAllUsers();
            initPage();
            initAsideModal();
        })();

        function initPage() {
            vm.pager = {};
            vm.setPage = setPage;
        }

        function setPage(page) {
            if (page < 1 || page > vm.pager.totalPages) {
                return;
            }

            // get pager object from service
            vm.pager = PagerService.GetPager(vm.allUsers.length, page);

            // get current page of items
            vm.pagedUsers = vm.allUsers.slice(vm.pager.startIndex, vm.pager.endIndex);
        }

        function initAsideModal() {
            vm.myAside = $aside({
                scope: $scope,
                title: 'Add User',
                //content: vm.userId,
                templateUrl: 'views/home/add-edit-user.html',
                container: "body",
                show: false,
                backdrop: "static",
                animation: "am-slide-top",
                keyboard: "false",
                placement: "left"
            });
        }

        function loadCurrentUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username)
                .then(function (user) {
                    vm.currentuser = user;
                });
        }

        function loadUser(userId, callback) {
            UserService.GetById(userId)
                .then(function (user) {
                    vm.user = user;
                    callback();
                });
        }

        function loadAllUsers() {
            UserService.GetAll()
                .then(function (users) {
                    vm.allUsers = users;
                    // initialize to page 1
                    vm.setPage(1);
                });
        }
    }
})();