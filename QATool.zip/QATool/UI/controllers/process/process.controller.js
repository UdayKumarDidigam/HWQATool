﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ProcessController', ProcessController);

    ProcessController.$inject = ['ProcessService', '$confirm', '$alert'];
    function ProcessController(ProcessService, $confirm, $alert) {
        var vm = this;

        vm.allProcesses = [];
        vm.originalData = [];
        vm.addProcess = addProcess;
        vm.saveProcess = saveProcess;
        vm.deleteProcess = deleteProcess;
        vm.cancelProcess = cancelProcess;
        //id
        //name
        //qualityBenchMark
        //version        
        //isActive

        (function initController() {
            loadAllProcesses();
        })();

        function loadAllProcesses() {
            ProcessService.GetAll()
                .then(function (processes) {
                    vm.allProcesses = processes;
                    vm.originalData = angular.copy(processes);
                });
        }

        function addProcess() {
            vm.allProcesses.unshift({ id: 0, isFlipped: true });
        }

        function cancelProcess(index) {
            var process = vm.allProcesses[index];
            if (process.id == 0)
                vm.allProcesses.splice(index, 1);
            else {
                var original = angular.copy(vm.originalData[index]);
                process.name = original.name;
                process.qualityBenchMark = original.qualityBenchMark;
                process.isActive = original.isActive;
                process.isFlipped = !process.isFlipped
            }
        }

        function saveProcess(index) {
            var process = vm.allProcesses[index];
            if (process.id == 0)
                ProcessService.Create(process)
                    .then(function (response) {                        
                        if (response.success) {
                            $alert({ title: 'Success!', content: 'Process saved successful', placement: 'top-right', type: 'success', show: true, duration: 3 });
                            process.isFlipped = !process.isFlipped
                        } else {
                            $alert({ title: 'Error!', content: response.message, placement: 'top-right', type: 'danger', show: true, duration: 3 });
                        }
                    });
            else {
                ProcessService.Update(process)
                    .then(function (response) {
                        if (response.success) {
                            $alert({ title: 'Success!', content: 'Process saved successful', placement: 'top-right', type: 'success', show: true, duration: 3 });
                            process.isFlipped = !process.isFlipped
                        } else {
                            $alert({ title: 'Error!', content: response.message, placement: 'top-right', type: 'danger', show: true, duration: 3 });
                        }
                    });
            }
            
        }

        function deleteProcess(index) {
            var process = vm.allProcesses[index];
            $confirm({
                title: 'Confirm',
                content: 'Are you sure you want to delete process "' + process.name + '"?'
            }).then(function (res) {
                if (res === "yes") {
                    ProcessService.Delete(process.id)
                    .then(function () {
                        loadAllProcesses();
                    });
                }
            });
        }
    }
})();