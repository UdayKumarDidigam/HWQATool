﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('LoginController', LoginController);

    LoginController.$inject = ['$location', 'AuthenticationService', 'ProcessService', 'FlashService', '$rootScope'];
    function LoginController($location, AuthenticationService, ProcessService, FlashService, $rootScope) {
        var vm = this;

        vm.login = login;

        (function initController() {
            // reset login status
            AuthenticationService.ClearCredentials();
        })();

        function login() {
            vm.dataLoading = true;
            delete vm.login.error;
            AuthenticationService.Login(vm.username, vm.password, function (response) {
                if (response.success) {
                    ProcessService.GetAllActive()
                        .then(function (processes) {
                            $rootScope.processes = processes;
                            AuthenticationService.SetCredentials(vm.username, vm.password);
                            $location.path('/');
                        });                    
                } else {
                    vm.login.error = { message: response.message };
                    vm.dataLoading = false;
                }
            });
        };
    }

})();
