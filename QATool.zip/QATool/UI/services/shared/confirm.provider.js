﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('$confirm', confirmProvider);

    confirmProvider.$inject = ['$modal', '$rootScope', '$q'];
    function confirmProvider($modal, $rootScope, $q) {
        return function (config) {
            var scope = $rootScope.$new(),
              deferred = $q.defer(),
              confirm;
            scope.title = config.title;
            scope.content = config.content;
            scope.answer = function (res) {
                deferred.resolve(res);
                confirm.hide();
            };
            confirm = $modal({
                templateUrl: 'views/shared/confirm.tpl.html',
                scope: scope,
                show: false
            });
            confirm.$promise.then(confirm.show);
            return deferred.promise;
        };
    }
})();