﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('ProcessService', ProcessService);

    ProcessService.$inject = ['$http'];
    function ProcessService($http) {
        var service = {};

        service.GetAll = GetAll;
        service.GetAllActive = GetAllActive;
        service.Create = Create;
        service.Update = Update;
        service.Delete = Delete;

        return service;

        function GetAll() {
            return $http.get('/api/teams').then(handleSuccess, handleError('Error getting all Processes'));
        }

        function GetAllActive() {
            return $http.get('/api/teams/active').then(handleSuccess, handleError('Error getting all active Processes'));
        }

        function Create(process) {
            return $http.post('/api/teams', process).then(handleSuccess, handleError('Error creating process'));
        }

        function Update(process) {
            return $http.put('/api/teams/' + process.id, process).then(handleSuccess, handleError('Error updating process'));
        }

        function Delete(id) {
            return $http.delete('/api/teams/' + id).then(handleSuccess, handleError('Error deleting process'));
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(error) {
            return function () {
                return { success: false, message: error };
            };
        }
    }

})();
