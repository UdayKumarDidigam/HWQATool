﻿(function () {
    'use strict';

    angular
        .module('app', ['ngRoute', 'ngCookies', 'ngAnimate', 'ngSanitize', 'mgcrea.ngStrap.aside', 'ngRouteAnimationManager'])
        .config(config)
        .run(run)
        .config(function ($asideProvider) {
            angular.extend($asideProvider.defaults, {
                animation: 'am-fadeAndSlideLeft',
                placement: 'left'
            });
        });
    config.$inject = ['$routeProvider', '$locationProvider', 'RouteAnimationManagerProvider'];
    function config($routeProvider, $locationProvider, RouteAnimationManagerProvider) {
        debugger;
        $routeProvider
            .when('/', {
                controller: 'HomeController',
                templateUrl: 'views/home/home.view.html',
                controllerAs: 'vm',
                data: {
                    animationConf: {
                        one: 'fade',
                        fallback: 'slide'
                    }
                }
            })
            .when('/team', {
                controller: 'TeamController',
                templateUrl: 'views/team/team.view.html',
                controllerAs: 'vm',
                data: {
                    animationConf: {
                        one: 'fade',
                        fallback: 'slide'
                    }
                }
            })

            .when('/login', {
                controller: 'LoginController',
                templateUrl: 'views/login/login.view.html',
                controllerAs: 'vm',
                data: {
                    animationConf: {
                        root: 'flip',
                        fallback: 'rotate'
                    }
                }
            })

            .when('/register', {
                controller: 'RegisterController',
                templateUrl: 'views/register/register.view.html',
                controllerAs: 'vm',
                data: {
                    animationConf: {
                        fallback: 'slide'
                    }
                }
            })
            .when('/register123', {
                controller: 'RegisterController',
                templateUrl: 'views/register/register.view.html',
                controllerAs: 'vm',
                data: {
                    animationConf: {
                    }
                }
            })

            .otherwise({ redirectTo: '/login' });

        RouteAnimationManagerProvider.setDefaultAnimation('fade');
    }

    run.$inject = ['$rootScope', '$location', '$cookieStore', '$http'];
    function run($rootScope, $location, $cookieStore, $http) {
        debugger;

        // keep user logged in after page refresh
        $rootScope.globals = $cookieStore.get('globals') || {};
        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        }

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in and trying to access a restricted page
            var restrictedPage = $.inArray($location.path(), ['/login', '/register', '/team']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                $location.path('/login');
            }
        });

        
    }

    })();