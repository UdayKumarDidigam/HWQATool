﻿(function () {
    'use strict';

    angular
        .module('app', ['ui.router', 'ngAnimate', 'ngCookies', 'mgcrea.ngStrap', 'ngSanitize'])
        .config(config)
        .run(run);    

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$locationProvider'];
    function config($stateProvider, $urlRouterProvider, $locationProvider) {

        // default route
        $urlRouterProvider.otherwise('/upload');

        //enable html5mode routing
        $locationProvider.html5Mode(true);

        // app routes
        $stateProvider
            .state('login', {
                url: '/login',
                templateUrl: 'views/login/login.view.html',
                controller: 'LoginController',
                controllerAs: 'vm'
            })
            .state('home', {
                url: '/home',
                templateUrl: 'views/home/home.view.html',
                controller: 'HomeController',
                controllerAs: 'vm'
            })
            .state('process', {
                url: '/process',
                templateUrl: 'views/process/process.view.html',
                controller: 'ProcessController',
                controllerAs: 'vm'
            })
            .state('upload', {
                url: '/upload',
                templateUrl: 'views/upload/upload.view.html',
                controller: 'UploadController',
                controllerAs: 'vm'
            })




            .state('register', {
                url: '/register',
                templateUrl: 'views/register/register.view.html',
                controller: 'RegisterController',
                controllerAs: 'vm'
            });
    }

    run.$inject = ['$rootScope', '$location', '$cookies', '$http'];
    function run($rootScope, $location, $cookies, $http) {
        // keep user logged in after page refresh
        $rootScope.globals = $cookies.getObject('globals') || {};
        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata;
        }

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in and trying to access a restricted page
            var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                $location.path('/login');
            }
            if (restrictedPage)
                $rootScope.showMenu = true;
            else
                $rootScope.showMenu = false;
        });
    }

})();