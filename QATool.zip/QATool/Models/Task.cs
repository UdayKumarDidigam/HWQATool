﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QATool.ViewModels
{
    [Table("tblTask")]
    public class Task : BaseEntity<int>
    {

        [Required]
        [MaxLength(200)]
        [Index("UK_tblTask_Name", 1, IsUnique = true)]
        public string Name { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:F2}")]
        public decimal SamplePercentage { get; set; }

        [Required]
        [Index("UK_tblTask_Name", 2, IsUnique = true)]
        public int TeamId { get; set; }

        [ForeignKey("TeamId")]
        public virtual Team Team { get; set; }

    }

}
