﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace QATool.ViewModels
{
    public class WebApiContext : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx

        public WebApiContext()
            : base("name=WebApiContext")
        {
        }
        public DbSet<Team> Teams { get; set; }
        public DbSet<Task> Tasks { get; set; }
        public DbSet<SubTask> SubTasks { get; set; }
        public DbSet<Error> Errors { get; set; }
        public DbSet<Platform> Platforms { get; set; }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Grade> Grades { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<Audit> Audits { get; set; }
        public DbSet<AuditFinding> AuditFindings { get; set; }
        public DbSet<AuditTimeSlot> AuditTimeSlots { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Error>()
                .HasRequired(c => c.Task)
                .WithMany()
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AuditTimeSlot>()
                .HasRequired(c => c.AuditedBy)
                .WithMany()
                .WillCascadeOnDelete(false);
        }

    }
}
