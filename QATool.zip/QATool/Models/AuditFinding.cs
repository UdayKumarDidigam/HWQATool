﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace QATool.ViewModels
{

    [Table("tblAuditFinding")]
    public class AuditFinding : BaseEntity<long>
    {
        [Required]
        [Index("UK_AuditFinding_AuditId_ErrorId", IsUnique = true, Order = 1)]
        public long AuditId { get; set; }

        [ForeignKey("AuditId")]
        public virtual Audit Audit { get; set; }

        [Required]
        [Index("UK_AuditFinding_AuditId_ErrorId", IsUnique = true, Order = 2)]
        public int ErrorId { get; set; }

        [ForeignKey("ErrorId")]
        public virtual Error Error { get; set; }
    }
}