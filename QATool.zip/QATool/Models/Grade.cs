﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace QATool.ViewModels
{
    [Table("tblGrade")]
    public class Grade : BaseEntity<int>
    {
        [MaxLength(200)]
        [Required]
        [Index("UK_tblGrade_Name", IsUnique = true, Order = 1)]
        public string Name { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:F2}")]
        public decimal SamplePercentage { get; set; }

        [Index("UK_tblPlatform_Name", IsUnique = true, Order = 2)]
        public int TeamId { get; set; }

        [ForeignKey("TeamId")]
        public virtual Team team { get; set; }

    }

}