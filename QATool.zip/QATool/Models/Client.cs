﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QATool.ViewModels
{
    [Table("tblClient")]
    public class Client : BaseEntity<int>
    {
        [Required]
        [MaxLength(200)]
        [Index("UK_tblClient_Name", IsUnique = true, Order = 1)]
        public string Name { get; set; }

        [Required]
        [Index("UK_tblClient_Name", IsUnique = true, Order = 2)]
        public int TeamId { get; set; }

        [ForeignKey("TeamId")]
        public virtual Team Team { get; set; }

        [Required]
        public bool IsKeyClient { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:F2}")]
        public decimal SamplePercentage { get; set; }

    }
    
}
