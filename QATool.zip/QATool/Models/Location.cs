﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QATool.ViewModels
{
    public enum Location
    {
        Hyderabad = 1,
        Pune,
        US,
        Other
    }
}
