﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QATool.ViewModels
{
    [Table("tblError")]
    public class Error : BaseEntity<int>
    {
        [Required]
        [MaxLength(100)]
        [Index("UK_tblError_Name", IsUnique = true, Order = 1)]
        public string Name { get; set; }

        [Required]
        [MaxLength(300)]
        public string Description { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:F2}")]
        public decimal Weightage { get; set; }

        [Index("UK_tblError_Error", IsUnique = true, Order = 2)]
        public int TaskId { get; set; }

        [ForeignKey("TaskId")]
        public virtual Task Task { get; set; }

    }



}
