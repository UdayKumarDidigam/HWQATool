﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
namespace QATool.ViewModels
{
    [Table("tblSubTask")]
    public class SubTask : BaseEntity<int>
    {
        [Required]
        [MaxLength(200)]
        [Index("UK_SubTask_Name", 1, IsUnique = true)]
        public string Name { get; set; }

        [Required]
        [Index("UK_SubTask_Name", 2, IsUnique = true)]
        public int TaskId { get; set; }

        [ForeignKey("TaskId")]
        public virtual Task Task { get; set; }

    }

}