﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace QATool.ViewModels
{
    [Table("tblAuditTimeSlot")]
    public class AuditTimeSlot : BaseEntity<long>
    {
        [Required]
        [Index("UK_AuditTimeSlot_AuditId", IsUnique = true)]
        public long AuditId { get; set; }

        [ForeignKey("AuditId")]
        public virtual Audit Audit { get; set; }

        [Required]
        [Index("UK_AuditTimeSlot_UserId", IsUnique = true)]        
        public int Auditor { get; set; }
        [ForeignKey("Auditor")]
        public virtual User AuditedBy { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? TotalTime { get; set; }
        public Status status { get; set; }
    }
}