﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QATool.ViewModels
{
    [Table("tblUser")]
    public class User : BaseEntity<int>
    {
        [Required]
        [MaxLength(100)]
        [Index("UK_tblUser_ESLoginId", IsUnique = true)]
        public string ESLoginId { get; set; }

        [Required]
        [MaxLength(100)]
        [Index("UK_tblUser_AssociateId", IsUnique = true)]
        public string AssociateId { get; set; }

        [Required]
        [MaxLength(200)]
        [Index("UK_tblUser_Email", IsUnique = true)]
        public string Email { get; set; }

        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; }

        [Required]
        [MaxLength(100)]
        public string LastName { get; set; }

        [Required]
        public Location Location { get; set; }

        [Required]
        [MaxLength(200)]
        public string SupervisorEmail { get; set; }

        [Required]
        public int GradeId { get; set; }

        [ForeignKey("GradeId")]
        public virtual Grade Grade { get; set; }

        [DisplayFormat(DataFormatString = "{0:F2}")]
        public decimal? SamplePercentage { get; set; }        

        public string Comments { get; set; }
        public virtual ICollection<Role> Roles { get; set; }
    }
}
