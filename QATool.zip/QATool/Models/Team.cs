﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QATool.ViewModels
{
    [Table("tblTeam")]
    public class Team : BaseEntity<int>
    {
        [Required(ErrorMessage = "Name is required")]
        [MaxLength(100)]
        [Index("UK_tblTeam_Name", IsUnique = true)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Quality Bench Mark is required")]
        [Range(0.00, 100.00, ErrorMessage = "Quality Bench Mark must be between 0.00 and 100.00")]
        [DisplayFormat(DataFormatString = "{0:F2}")]
        public decimal QualityBenchMark { get; set; }

    }
}
