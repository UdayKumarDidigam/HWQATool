﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QATool.ViewModels
{
    [Table("tblPlatform")]
    public class Platform : BaseEntity<int>
    {

        [Required]
        [MaxLength(200)]
        [Index("UK_tblPlatform_Name", IsUnique = true, Order = 1)]
        public string Name { get; set; }
        [Index("UK_tblPlatform_Name", IsUnique = true, Order = 2)]
        public int TeamId { get; set; }

        [ForeignKey("TeamId")]
        public virtual Team team { get; set; }

    }

}
