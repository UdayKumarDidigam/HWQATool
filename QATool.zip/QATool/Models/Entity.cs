﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QATool.ViewModels
{
    public abstract class BaseEntity<T> 
    {
        public virtual T Id { get; set; }
        public int Version { get; set; }
        public bool IsActive { get; set; }
        public DateTime LastModifiedAt { get; set; }
        public string LastModifiedBy { get; set; }

        public BaseEntity()
        {
            LastModifiedAt = DateTime.Now;
            Version = 1;
            IsActive = true;
            LastModifiedBy = System.Web.HttpContext.Current.User.Identity.Name;
        }
    }
}
