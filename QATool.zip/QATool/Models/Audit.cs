﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace QATool.ViewModels
{
    [Table("tblAudit")]
    public class Audit:BaseEntity<long>
    {
        [MaxLength(200)]
        public string AuditNo { get; set; }

        [MaxLength(200)]
        public string ConfirmationNo { get; set; }

        [MaxLength(200)]
        public string ServiceRequestNo { get; set; }

        public DateTime ProcessedDate { get; set; }

        
        public int? Processor { get; set; }
        [ForeignKey("Processor")]
        public virtual User ProcessedBy { get; set; }

        public int? ClientId { get; set; }

        [ForeignKey("ClientId")]
        public virtual Client Client { get; set; }

        public int? SubTaskId { get; set; }

        [ForeignKey("SubTaskId")]
        public virtual SubTask SubTask { get; set; }

        public int TaskId { get; set; }

        [ForeignKey("TaskId")]
        public virtual Task Task { get; set; }

        public int? Auditor { get; set; }
        [ForeignKey("Auditor")]
        public virtual User AuditedBy { get; set; }
        public DateTime AuditDate { get; set; }
        [MaxLength(350)]
        public string Comments { get; set; }
        public bool IsDefect { get; set; }
        public bool IsLearning { get; set; }
        public bool IsEscalation { get; set; }
        public bool IsClientFocus { get; set; }
        public bool IsDuplicate { get; set; }
        public bool IsSampled { get; set; }
        public int? NoOfRecords { get; set; }
        public int? TotalDefects { get; set; }
        public Status Status { get; set; }
        public int? PlatformId { get; set; }
        [ForeignKey("PlatformId")]     
        public virtual Platform Platform { get; set; }
    }
}