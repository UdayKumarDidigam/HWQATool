﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using QATool.ViewModels;

namespace QATool.Controllers
{
    public class AuditFindingsController : ApiController
    {
        private WebApiContext db = new WebApiContext();

        // GET api/AuditFindings
        public IQueryable<AuditFinding> GetAuditFindings()
        {
            return db.AuditFindings;
        }

        // GET api/AuditFindings/5
        [ResponseType(typeof(AuditFinding))]
        public IHttpActionResult GetAuditFinding(long id)
        {
            AuditFinding auditfinding = db.AuditFindings.Find(id);
            if (auditfinding == null)
            {
                return NotFound();
            }

            return Ok(auditfinding);
        }

        // PUT api/AuditFindings/5
        public IHttpActionResult PutAuditFinding(long id, AuditFinding auditfinding)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != auditfinding.Id)
            {
                return BadRequest();
            }

            db.Entry(auditfinding).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AuditFindingExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/AuditFindings
        [ResponseType(typeof(AuditFinding))]
        public IHttpActionResult PostAuditFinding(AuditFinding auditfinding)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.AuditFindings.Add(auditfinding);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = auditfinding.Id }, auditfinding);
        }

        // DELETE api/AuditFindings/5
        [ResponseType(typeof(AuditFinding))]
        public IHttpActionResult DeleteAuditFinding(long id)
        {
            AuditFinding auditfinding = db.AuditFindings.Find(id);
            if (auditfinding == null)
            {
                return NotFound();
            }

            db.AuditFindings.Remove(auditfinding);
            db.SaveChanges();

            return Ok(auditfinding);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool AuditFindingExists(long id)
        {
            return db.AuditFindings.Count(e => e.Id == id) > 0;
        }
    }
}