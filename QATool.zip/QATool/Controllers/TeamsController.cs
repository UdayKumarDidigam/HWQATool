﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using QATool.ViewModels;
using QATool.ViewModels;

namespace QATool.Controllers
{
    public class TeamsController : ApiController
    {
        private WebApiContext db = new WebApiContext();

        // GET api/Team
        public IQueryable<Team> GetTeams()
        {
            return db.Teams;
        }

        [Route("api/Teams/Active")]
        public IQueryable<Team> GetActiveTeams()
        {
            return db.Teams.Where(x => x.IsActive == true);
        }

        [Route("api/teams/getpaged/{pageNo:int?}/{pageSize:int?}")]
        public IHttpActionResult GetPaged(int pageNo = 1, int pageSize = 50)
        {
            // Return the list of customers
            return Ok(new PagedResult<Team>(db.Teams, pageNo, pageSize));
        }


        // GET api/Team/5
        [ResponseType(typeof(Team))]
        public IHttpActionResult GetTeam(int id)
        {
            Team team = db.Teams.Find(id);
            if (team == null)
            {
                return NotFound();
            }

            return Ok(team);
        }

        // PUT api/Team/5
        public IHttpActionResult PutTeam(int id, Team team)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != team.Id)
            {
                return BadRequest();
            }

            db.Entry(team).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TeamExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok(new GenericResponse() { Success = true, Data = team });
        }

        // POST api/Team
        [ResponseType(typeof(Team))]
        public IHttpActionResult PostTeam(Team team)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Teams.Add(team);
            db.SaveChanges();

            return Ok(new GenericResponse() { Success = true, Data = team });
        }

        // DELETE api/Team/5
        [ResponseType(typeof(Team))]
        public IHttpActionResult DeleteTeam(int id)
        {
            Team team = db.Teams.Find(id);
            if (team == null)
            {
                return NotFound();
            }

            db.Teams.Remove(team);
            db.SaveChanges();

            return Ok(team);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TeamExists(int id)
        {
            return db.Teams.Count(e => e.Id == id) > 0;
        }
    }
}