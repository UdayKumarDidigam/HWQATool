﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using QATool.ViewModels;

namespace QATool.Controllers
{
    public class UserRolesController : ApiController
    {
        private WebApiContext db = new WebApiContext();

        // GET api/UserRoles
        public IQueryable<UserRole> GetUserRoles()
        {
            return db.UserRoles;
        }

        // GET api/UserRoles/5
        [ResponseType(typeof(UserRole))]
        public IHttpActionResult GetUserRole(long id)
        {
            UserRole userrole = db.UserRoles.Find(id);
            if (userrole == null)
            {
                return NotFound();
            }

            return Ok(userrole);
        }

        // PUT api/UserRoles/5
        public IHttpActionResult PutUserRole(long id, UserRole userrole)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != userrole.Id)
            {
                return BadRequest();
            }

            db.Entry(userrole).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserRoleExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/UserRoles
        [ResponseType(typeof(UserRole))]
        public IHttpActionResult PostUserRole(UserRole userrole)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.UserRoles.Add(userrole);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = userrole.Id }, userrole);
        }

        // DELETE api/UserRoles/5
        [ResponseType(typeof(UserRole))]
        public IHttpActionResult DeleteUserRole(long id)
        {
            UserRole userrole = db.UserRoles.Find(id);
            if (userrole == null)
            {
                return NotFound();
            }

            db.UserRoles.Remove(userrole);
            db.SaveChanges();

            return Ok(userrole);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UserRoleExists(long id)
        {
            return db.UserRoles.Count(e => e.Id == id) > 0;
        }
    }
}