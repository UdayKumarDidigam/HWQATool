﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using QATool.ViewModels;

namespace QATool.Controllers
{
    public class AuditTimeSlotsController : ApiController
    {
        private WebApiContext db = new WebApiContext();

        // GET api/AuditTimeSlots
        public IQueryable<AuditTimeSlot> GetAuditTimeSlots()
        {
            return db.AuditTimeSlots;
        }

        // GET api/AuditTimeSlots/5
        [ResponseType(typeof(AuditTimeSlot))]
        public IHttpActionResult GetAuditTimeSlot(long id)
        {
            AuditTimeSlot audittimeslot = db.AuditTimeSlots.Find(id);
            if (audittimeslot == null)
            {
                return NotFound();
            }

            return Ok(audittimeslot);
        }

        // PUT api/AuditTimeSlots/5
        public IHttpActionResult PutAuditTimeSlot(long id, AuditTimeSlot audittimeslot)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != audittimeslot.Id)
            {
                return BadRequest();
            }

            db.Entry(audittimeslot).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AuditTimeSlotExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/AuditTimeSlots
        [ResponseType(typeof(AuditTimeSlot))]
        public IHttpActionResult PostAuditTimeSlot(AuditTimeSlot audittimeslot)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.AuditTimeSlots.Add(audittimeslot);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = audittimeslot.Id }, audittimeslot);
        }

        // DELETE api/AuditTimeSlots/5
        [ResponseType(typeof(AuditTimeSlot))]
        public IHttpActionResult DeleteAuditTimeSlot(long id)
        {
            AuditTimeSlot audittimeslot = db.AuditTimeSlots.Find(id);
            if (audittimeslot == null)
            {
                return NotFound();
            }

            db.AuditTimeSlots.Remove(audittimeslot);
            db.SaveChanges();

            return Ok(audittimeslot);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool AuditTimeSlotExists(long id)
        {
            return db.AuditTimeSlots.Count(e => e.Id == id) > 0;
        }
    }
}