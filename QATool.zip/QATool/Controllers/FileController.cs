﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace QATool.Controllers
{
    public class FileController : ApiController
    {
        [HttpPost]
        [Route("api/file/uploadfile")]
        public void UploadFile()
        {
            if (HttpContext.Current.Request.Files.AllKeys.Any())
            {
                var httpPostedFile = HttpContext.Current.Request.Files["file"];

                if (!Directory.Exists(HttpContext.Current.Server.MapPath("~/UploadedDocuments")))
                    Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/UploadedDocuments"));

                var fileSavePath = Path.Combine(HttpContext.Current.Server.MapPath("~/UploadedDocuments"),
                                                httpPostedFile.FileName);
                httpPostedFile.SaveAs(fileSavePath);

            }
        }

        [HttpPost()]
        [Route("api/file/uploadfiles")]
        public string UploadFiles()
        {
            int iUploadedCnt = 0;

            // DEFINE THE PATH WHERE WE WANT TO SAVE THE FILES.
            string sPath = "";
            sPath = System.Web.Hosting.HostingEnvironment.MapPath("~/UploadedDocuments");

            System.Web.HttpFileCollection hfc = System.Web.HttpContext.Current.Request.Files;

            // CHECK THE FILE COUNT.
            for (int iCnt = 0; iCnt <= hfc.Count - 1; iCnt++)
            {
                System.Web.HttpPostedFile hpf = hfc[iCnt];

                if (hpf.ContentLength > 0)
                {
                    // CHECK IF THE SELECTED FILE(S) ALREADY EXISTS IN FOLDER. (AVOID DUPLICATE)
                    if (!File.Exists(sPath + Path.GetFileName(hpf.FileName)))
                    {
                        // SAVE THE FILES IN THE FOLDER.
                        hpf.SaveAs(Path.Combine(sPath, Path.GetFileName(hpf.FileName)));
                        iUploadedCnt = iUploadedCnt + 1;
                    }
                }
            }

            // RETURN A MESSAGE.
            if (iUploadedCnt > 0)
            {
                return iUploadedCnt + " Files Uploaded Successfully";
            }
            else
            {
                return "Upload Failed";
            }
        }

        [HttpGet()]
        [Route("api/file/download")]
        public void Download()
        {
            var students = new[]
            {
                new {
                    Id = "101", Name = "Vivek", Address = "Hyderabad"
                },
                new {
                    Id = "102", Name = "Ranjeet", Address = "Hyderabad"
                },
                new {
                    Id = "103", Name = "Sharath", Address = "Hyderabad"
                },
                new {
                    Id = "104", Name = "Ganesh", Address = "Hyderabad"
                },
                new {
                    Id = "105", Name = "Gajanan", Address = "Hyderabad"
                },
                new {
                    Id = "106", Name = "Ashish", Address = "Hyderabad"
                }
            };
            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.TabColor = System.Drawing.Color.Black;
            workSheet.DefaultRowHeight = 12;
            //Header of table  
            //  
            workSheet.Row(1).Height = 20;
            workSheet.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            workSheet.Row(1).Style.Font.Bold = true;
            workSheet.Cells[1, 1].Value = "S.No";
            workSheet.Cells[1, 2].Value = "Id";
            workSheet.Cells[1, 3].Value = "Name";
            workSheet.Cells[1, 4].Value = "Address";
            //Body of table  
            //  
            int recordIndex = 2;
            foreach (var student in students)
            {
                workSheet.Cells[recordIndex, 1].Value = (recordIndex - 1).ToString();
                workSheet.Cells[recordIndex, 2].Value = student.Id;
                workSheet.Cells[recordIndex, 3].Value = student.Name;
                workSheet.Cells[recordIndex, 4].Value = student.Address;
                recordIndex++;
            }
            workSheet.Column(1).AutoFit();
            workSheet.Column(2).AutoFit();
            workSheet.Column(3).AutoFit();
            workSheet.Column(4).AutoFit();
            string excelName = "studentsRecord";
            using (var memoryStream = new MemoryStream())
            {
                HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=" + excelName + ".xlsx");
                excel.SaveAs(memoryStream);
                memoryStream.WriteTo(HttpContext.Current.Response.OutputStream);
                HttpContext.Current.Response.Flush();
                HttpContext.Current.Response.End();
            }
        }
    }
}
