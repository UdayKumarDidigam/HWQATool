﻿(function () {
    'use strict';

    angular
        .module('app')
        .directive('topBanner', topBanner);

    topBanner.$inject = ['$location'];
    function topBanner($location) {
        return {
            restrict: "E",
            templateUrl: "directives/topbanner/topbanner.view.html",
            controller: function () {
                // do stuff...
            }
        };
    }
})();