﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['UserService', '$rootScope', '$scope', '$aside', '$state'];
    function HomeController(UserService, $rootScope, $scope, $aside, $state) {
        var vm = this;

        vm.user = null;
        vm.allUsers = [];
        vm.deleteUser = deleteUser;
        vm.Process = Process;

        initController();

        function initController() {
            loadCurrentUser();
            loadAllUsers();
        }

        function loadCurrentUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username)
                .then(function (user) {
                    vm.user = user;
                });
        }

        function loadAllUsers() {
            UserService.GetAll()
                .then(function (users) {
                    vm.allUsers = users;
                });
        }

        function deleteUser(id) {
            UserService.Delete(id)
            .then(function () {
                loadAllUsers();
            });
        }

        function Process() {
            $state.go("process");
        }

        $scope.showModal = function () {
            debugger;
            // Show a basic modal from a controller
            var myAside = $aside({ title: 'My Title', content: 'My Content', show: true, animation: 'am-fade-and-slide-right', placement: 'right' });
        }
    }

})();