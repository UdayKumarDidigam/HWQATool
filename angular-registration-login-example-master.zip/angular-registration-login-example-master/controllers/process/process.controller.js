﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ProcessController', ProcessController);

    ProcessController.$inject = ['UserService', '$rootScope', '$scope', '$aside'];
    function ProcessController(UserService, $rootScope, $scope, $aside) {
        var vm = this;

        vm.user = null;
        vm.allUsers = [];
        vm.deleteUser = deleteUser;

        initController();

        function initController() {
            loadCurrentUser();
            loadAllUsers();
        }

        function loadCurrentUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username)
                .then(function (user) {
                    vm.user = user;
                });
        }

        function loadAllUsers() {
            UserService.GetAll()
                .then(function (users) {
                    vm.allUsers = users;
                });
        }

        function deleteUser(id) {
            UserService.Delete(id)
            .then(function () {
                loadAllUsers();
            });
        }


        $scope.showModal = function () {
            debugger;
            // Show a basic modal from a controller
            var myAside = $aside({ title: 'My Title', content: 'My Content', show: true, animation: 'am-fade-and-slide-right', placement: 'right' });
        }
    }

})();